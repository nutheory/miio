<div id="find_members">
	<h2>Find members that like the same things you do<a href="#" onclick="return Signup.NextStep()">skip</a></h2>
	<ul>
		<li>
			<p>
				Simply type a list of things or topics you like, and Miio will display a list of members that like the same things you do.
			</p>
		</li>
		<li>
		  <!--
			<div id="" class="count">
				140
			</div>
			-->
			<div class="instruct">
				Example: Lakers technology BMW cupcakes NBA
			</div>
			<textarea id="member_interests" class="full" onkeypress="Forms.Enter(event,this,Signup.FindMembers)"></textarea>
			<!--<p>(Up to 140 characters. Use spaces to separate the keywords.)</p>-->
		</li>
		<li class="buttons">
			<div class="right_buttons">
				<button class="short_button" onclick="Signup.FindMembers()">Find members</button>
			</div>
			<a href="#" onclick="return Signup.LastStep()">back</a>	
		</li>
	</ul>
</div>