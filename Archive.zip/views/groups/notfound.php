<? global $PARAMS; ?>

<link href="css/error.css" rel="stylesheet" type="text/css">
<!--<script type="text/javascript" src="js/error.js"></script>-->

<table><tr><td id="left_col">&nbsp;</td><td id="center_col">
  <div id="error_div" class="content_with_rcol">
    <h2>
      <img src="images/sad.png">
      Not Here
    </h2>
    <p>The Miio Group you are looking for ('<?= $PARAMS ?>') is not here.</p>
    <p>Try <a href="tabs/groups">browsing</a> or <a href="search/group">searching</a> Groups.</p>
  </div>
</td><td id="right_col"><!--<img src="filler/google_ads.gif">--></td></tr></table>
