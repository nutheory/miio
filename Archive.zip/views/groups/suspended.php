<? global $PARAMS, $Group; ?>

<link href="css/error.css" rel="stylesheet" type="text/css">
<!--<script type="text/javascript" src="js/error.js"></script>-->

<table><tr><td id="left_col">&nbsp;</td><td id="center_col">
  <div id="error_div" class="content_with_rcol">
    <h2>
      <img src="images/sad.png">
      Suspended
    </h2>
    <p>Sorry. This Group is under suspension for possible violations of our <a href="pages/terms">Terms of Use</a>.</p>
    <p>Pending our review this group will either be fully restored or permanently removed within 48 hours</p>
  </div>
</td><td id="right_col"><!--<img src="filler/google_ads.gif">--></td></tr></table>

