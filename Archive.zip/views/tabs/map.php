<? global $LOGGEDIN, $PAGE; ?>
<link href="css/tabs.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/tabs.js"></script>
<link href="css/map.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/map.js"></script>


<div id='tab_container'>
  <div id="google_map"></div>
</div>

<script type="text/javascript">
  Tabs.Init('<?= $PAGE ?>');
</script>