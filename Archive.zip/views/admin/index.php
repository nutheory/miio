

<ul>
	<li>Administration</li>
	<li><a href="admin/featured">Featured Users</a></li>
	<li><a href="admin/taglines">Taglines</a></li>
</ul>