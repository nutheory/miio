<? global $CONTROLLER;?>
<link href="css/featured.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/featured.js"></script>
<div id="featured">
	<div id="featured_content">
	</div>
</div>
<script type="text/javascript">
  Featured.Init('<?= $CONTROLLER ?>');
</script>