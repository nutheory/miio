<? global $PARAMS; ?>

<link href="css/error.css" rel="stylesheet" type="text/css">
<!--<script type="text/javascript" src="js/error.js"></script>-->

<table><tr><td id="left_col">&nbsp;</td><td id="center_col">
  <div id="error_div" class="content_with_rcol">
    <h2>
      <img src="images/sad.png">
      Not Here
    </h2>
    <p>The Miio Member or Group you are looking for ('<?= $PARAMS ?>') is not here.</p>
    <p>You can <a href="members">browse</a> or <a href="search/member">search</a> Members,</p>
    <p>Or you can <a href="tabs/groups">browse</a> or <a href="search/group">search</a> Groups.</p>
  </div>
</td><td id="right_col"><!--<img src="filler/google_ads.gif">--></td></tr></table>
