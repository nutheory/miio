<div id="pause_counter" style="display:none">
  <span id="pausecounter0" style="display:none">Paused</span>
  <span id="pausecounter1" style="display:none">Paused: 1 new message.</span>
  <span id="pausecounterx" style="display:none">Paused: <span id="pause_count">999</span> new messages.</span>
</div>