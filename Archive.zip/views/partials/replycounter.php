<? global $CONTROLLER,$PAGE,$PARAMS; ?>
<div id="reply_counter" style="display:none">
  <span id="replycounter0" style="display:none"></span>
  <span id="replycounter1" style="display:none">1 new reply. <a href="<?= $CONTROLLER ?>/<?= $PAGE ?>/<?= $PARAMS ?>">Refresh</a> to view.</span>
  <span id="replycounterx" style="display:none"><span id="reply_count">999</span> new replies. <a href="<?= $CONTROLLER ?>/<?= $PAGE ?>/<?= $PARAMS ?>">Refresh</a> to view.</span>
</div>