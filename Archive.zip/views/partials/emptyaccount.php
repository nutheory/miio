<? global $LOC; ?>
<div class="empty_account">
	<h2>Now what?</h2>
	<ul>
		<li>Tell everyone whats on your mind in the box above</li>
		<li>View what everyone is saying and sharing on the <a href="<?= $LOC ?>tabs/all">public timeline</a></li>
		<li><a href="<?= $LOC ?>members">Browse members</a>, or <a href="<?= $LOC ?>search/member">search members</a></li>
		<li><a href="<?= $LOC ?>tabs/groups">Browse groups</a>, <a href="<?= $LOC ?>user#groups/create">create a group</a>, or <a href="<?= $LOC ?>search/group">search groups</a></li>
		<li><a href="<?= $LOC ?>topics">View trending topics</a></li>
		<li><a href="<?= $LOC ?>user#settings/mobile">Confirm your mobile</a> phone to send and read messages on your phone</li>
	</ul>
</div>
