<div id="message_filter_container" class="message_filter" style="display:none">
  <input type="text" name="message_filter" id="message_filter" onkeyup="Messages.Filter(this.value);" onfocus="Messages.FilterFocus(this)" onblur="Messages.FilterBlur(this)" value="Filter">
  <div class="clearfilter">
    <img src="images/search_glass.png" id="filter_message_filter" alt="filter" title="Filter by sender or recipient's name">
    <img src="images/clear_filter.png" id="clear_message_filter" alt="clear filter" title="Clear filter" style="display:none" onclick="Messages.ClearFilter()">
  </div>
</div>