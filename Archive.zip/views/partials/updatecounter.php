<? global $LOC,$CONTROLLER,$PAGE,$PARAMS; ?>
<?
if ($CONTROLLER=='user')
{
  if ($PAGE=='index' || $PAGE=='') $refreshlink = "user";
}
?>
<div id="update_counter" style="display:none">
  <span id="updatecounter0" style="display:none"></span>
  <span id="updatecounter1" style="display:none">1 new message. <a href="#" onclick="return Messages.ReloadPage()">Refresh</a> to view.</span>
  <span id="updatecounterx" style="display:none"><span id="update_count">999</span> new messages. <a href="#" onclick="return Messages.ReloadPage()">Refresh</a> to view.</span>
</div>