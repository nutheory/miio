<?
/*#####*/
?>
</body>
<script type="text/javascript">
  Init('<?= $CONTROLLER ?>','<?= $PAGE ?>');
</script>

<!--[if IE 6]>
<link href="css/_ie6.css" rel="stylesheet" type="text/css">
<![endif]-->
<!--[if IE 7]>
<link href="css/_ie7.css" rel="stylesheet" type="text/css">
<![endif]-->
</html>