<?

?>
<? require_once BASE."includes/header.php" ?>

<div id="wrapper">
  <? require_once BASE."includes/controller.php" ?>
</div>

<? require_once BASE."includes/footer.php" ?>
