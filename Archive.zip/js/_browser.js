var B = {};

B.login_ht_adj = 143;
