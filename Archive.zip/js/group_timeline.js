Group.Timeline = {};

Group.Timeline.Init = function()
{
  DOM.Show('right_col');
  DOM.SetClass('content_div','content_with_rcol');
  DOM.Hide('user_filter_container');
  DOM.Hide('select_alert');
  Messages.Init('groups');
}

