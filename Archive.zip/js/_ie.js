if (typeof(B)=='undefined') var B = {};

B.login_ht_adj = 123;