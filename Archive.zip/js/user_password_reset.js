if (typeof(User)=='undefined') User = {};

User.Passwd = {};
