<?
exec ("/usr/bin/php trendprocess.php >/dev/null &#038;");
?>