<?
exec ("/usr/bin/php /var/www/beta.ikegger.com/queue/rss.php >/dev/null &#038;");
?>