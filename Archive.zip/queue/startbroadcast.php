<?
exec ("/usr/bin/php broadcast.php >/dev/null &#038;");
?>