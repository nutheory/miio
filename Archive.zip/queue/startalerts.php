<?
exec ("/usr/bin/php /var/www/beta.ikegger.com/queue/alerts.php >/dev/null &#038;");
?>