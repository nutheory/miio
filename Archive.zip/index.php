<?

if ($_SERVER['HTTP_HOST']=='localhost') require_once "/websites/miio/miio_config/config.php";
else require_once "/home/beta.miio.com/miio_config/config.php";

require_once BASE."dispatch.php";

// displays

if ($SHOW_HTML)
{
  require_once BASE."includes/html_head.php";

  require_once BASE."includes/main.php";

  require_once BASE."includes/html_foot.php";
}

?>